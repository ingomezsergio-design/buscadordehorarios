Oct/Nov 2025 Animated+ UI
- Placeholder mejorado (Seleccioná el mes -> cargando… -> Escribí un nombre…)
- Más animaciones: reveal, brillo en botón, ripple en celdas, ring del día de hoy, shimmer en Detalles.
